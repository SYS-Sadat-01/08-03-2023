package com.homeWork2;

public class Home2 {
	public static void main(String[] args) {
		System.out.println("I love coding❤️");
	}
}

