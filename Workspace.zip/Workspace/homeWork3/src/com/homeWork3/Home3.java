package com.homeWork3;

public class Home3 {
	public static void main(String[] args) {
		System.out.println("I am a new member");
	}

}
