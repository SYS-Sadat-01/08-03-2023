package com.homeWork;

public class Java {
	public static void main(String[] args) {
		System.out.println("My name is Sayed Yousuf Sadat");
	}

}

