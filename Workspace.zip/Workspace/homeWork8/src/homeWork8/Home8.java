package homeWork8;

public class Home8 {
	public static void main(String[] args) {
		System.out.println("This is my last project");
	}

}
