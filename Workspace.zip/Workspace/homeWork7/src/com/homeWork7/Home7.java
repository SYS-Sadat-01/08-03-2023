package com.homeWork7;

public class Home7 {
	public static void main(String[] args) {
		System.out.println("This is the second last project of my home work");
	}
}

