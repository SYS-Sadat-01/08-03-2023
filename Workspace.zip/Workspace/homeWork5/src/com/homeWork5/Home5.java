package com.homeWork5;

public class Home5 {
	public static void main(String[] args) {
		System.out.println("This is my Home Work");
	}

}
