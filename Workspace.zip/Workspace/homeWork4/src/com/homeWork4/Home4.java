package com.homeWork4;

public class Home4 {
	public static void main(String[] args) {
		System.out.println("This is my new laptop");
	}
}
