package com.test;

public class Test1 { // Curly brace
	public static void main(String[] args) {
		System.out.println("Hello Everyone, Hello World");
	}

}
