package com.homeWork1;

public class Home {
	public static void main(String[] args) {
		System.out.println("I am a student");
	}

}

